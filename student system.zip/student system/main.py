import csv
import os
#DISPLAY THE INTERFACE
while True:
    print("Welcome To The System ")
    print("~~~Unique Acdamey  ~~~")
    print("1. Add Student")
    print("2. View Student")
    print("3. Update Record")
    print("4. Save Record")
    print("5. Delete Record")
    print("6. Exit From System")

#CREAT FILE AND ADD HEADER
    file_name = "students.csv"
    if not os.path.exists(file_name):
        with open(file_name, "a", newline="") as file:
            writer = csv.writer(file)
            writer.writerow([
                "Student ID",
                "Student Name",
                "Student Age",
                "Student Email"
            ])
    #GET USER ACTION 
    user_act=int(input("Select the action which you want ="))
    #IF USER SELECT 1 THIS OPERATION WILL PERFORME
    if user_act ==1:
        print("Add Student Selected ")
        choice=[]
        while  choice != "no":
            std_id=int(input("Enter Student ID  ="))
            std_nam=input("Enter Student Name  =")
            std_age=int(input("Enter Student Age  ="))
            std_emil=input("Enter Student Email ID  =")
            #INSER\SAVE DATA IN CSV FILE
            with open("students.csv","a",newline="") as f:
                writer=csv.writer(f)
                writer.writerow([std_id,std_nam,std_age,std_emil])   
                print("Data Save")
                choice=input("Do You Want to Add More Studen yes/no =").lower()        
            if choice =="no":
             break
        print("Thanks for using The System")

    #IF USER SELECT 2 SO THIS ACTION WILL PERFORM
    elif user_act==2:
        with open("students.csv","r") as f:
            info=f.read()
            print(info)
    #IF USER SELECT 3 SO THIS OPERATION WILL PERFORME
    elif user_act==3:
        st_id=input("Enter Student Id =")
        rows=[]
        found=False
        with open("students.csv","r") as f:
            read_id=csv.reader(f)
            header = next(read_id)
            rows.append(header)
            for row in read_id :
                if row[0]==st_id:
                    print("found",row)
                    found=True
                    row[1]=input("Enter Student Name =")
                    row[2]=input("Enter Student Age =")
                    row[3]=input("Enter Student Email =")
                rows.append(row)
        with open("students.csv","w",newline="") as f:
            write=csv.writer(f)
            write.writerows(rows)
        if found == True:
            print("succely update")
        else:
            print("Not Found")
    #IF USER SELECT OPTION 4 THIS ACTION WILL PERFORME
    elif user_act==4:
        print("Record Save Successfully")
    #IF USER SELECTED OPTION 5 THIS OPERATION WILL PERFROME
    elif user_act==5:
        del_op=input("Enter Student ID To Delete Student Data =")# the data which store in csv in string form
        rows=[]
        found=False
        with open ("students.csv","r") as f:
            reader=csv.reader(f)
            header=next(reader)
            rows.append(header)
            for row in reader:
                if row[0]==del_op:
                    found=True
                    continue
                rows.append(row)
        with open("students.csv","w",newline="") as f:
            write=csv.writer(f)
            write.writerows(rows)
        if found ==True:
            print(f"Record Of ID No.{del_op} Is Deleted Successfully")
        else:
            print(f"The ID NO {del_op} Is Not Found")
    #IF USER SELECT OPTION 6 THIS OPERATION IS PERFOME
    elif user_act==6:
        print("Thank You For Using This System")
    #AGAR USER MAIN MENU SA AHIR KOI OPTION SELECT KARE TO YA OPERATION RUN HO JYE GA 
    else:
        print("Select The Avabile Option<Try Again>")